# Claude Code Instructions — Chat Word Index

This project contains `word_index.db`, a SQLite database built by `chat_indexer.exe`.
It indexes every word, character, symbol combo, and bracket pair from the user's
Claude Code sessions, split by speaker (user vs assistant).

---

## Database Schema

### `words`
| column   | type    | notes                          |
|----------|---------|--------------------------------|
| word     | TEXT    | lowercased, raw (typos intact) |
| speaker  | TEXT    | `'user'` or `'assistant'`      |
| count    | INTEGER | total occurrences              |
| sessions | INTEGER | number of sessions it appeared in |

### `characters`
| column   | type    | notes                          |
|----------|---------|--------------------------------|
| char     | TEXT    | every individual character     |
| speaker  | TEXT    | `'user'` or `'assistant'`      |
| count    | INTEGER | total occurrences              |
| sessions | INTEGER |                                |

### `symbol_combos`
| column   | type    | notes                                        |
|----------|---------|----------------------------------------------|
| combo    | TEXT    | auto-detected symbol sequences e.g. `=>`, `()`, `!==` |
| speaker  | TEXT    | `'user'` or `'assistant'`                    |
| count    | INTEGER | total occurrences                            |
| sessions | INTEGER |                                              |

### `bracket_pairs`
| column   | type    | notes                              |
|----------|---------|------------------------------------|
| pair     | TEXT    | matched pairs: `()`, `[]`, `{}`, `<>` |
| speaker  | TEXT    | `'user'` or `'assistant'`          |
| count    | INTEGER | total matched pair occurrences     |
| sessions | INTEGER |                                    |

### `sessions`
| column     | type | notes                        |
|------------|------|------------------------------|
| session_id | TEXT | `.jsonl` filename stem       |
| file_path  | TEXT | full path to source file     |
| indexed_at | TEXT | datetime of indexing         |

---

## Useful Queries

### Top user words
```sql
SELECT word, count FROM words WHERE speaker='user' ORDER BY count DESC LIMIT 30;
```

### Rare user words (potential typos)
```sql
SELECT word, count FROM words
WHERE speaker='user' AND count <= 2 AND length(word) > 3
ORDER BY word;
```

### Compare user vs assistant word usage
```sql
SELECT u.word, u.count as user_count, COALESCE(a.count,0) as assistant_count
FROM words u
LEFT JOIN words a ON u.word = a.word AND a.speaker='assistant'
WHERE u.speaker='user'
ORDER BY u.count DESC LIMIT 30;
```

### Most used symbol combos (user)
```sql
SELECT combo, count FROM symbol_combos WHERE speaker='user' ORDER BY count DESC LIMIT 20;
```

### Bracket pair usage
```sql
SELECT pair, count FROM bracket_pairs WHERE speaker='user' ORDER BY count DESC;
```

### Words the user uses but Claude never does
```sql
SELECT u.word, u.count FROM words u
WHERE u.speaker='user'
AND u.word NOT IN (SELECT word FROM words WHERE speaker='assistant')
ORDER BY u.count DESC LIMIT 30;
```

---

## Typo / Misspelling Analysis

The database stores words **as-is** (lowercased only). To find likely typos:

1. Pull rare words: `SELECT word FROM words WHERE speaker='user' AND count <= 3`
2. Compare against a word list, or ask Claude to identify which look like misspellings
3. Use edit distance (Levenshtein) to find close matches in the high-frequency words

Example prompt to Claude:
> "Here are words from my chat history that appear 3 or fewer times. Which look like typos and what did I probably mean? [paste list]"

---

## Running the indexer

```
# Index and show stats
chat_indexer.exe --stats

# Index only
chat_indexer.exe

# Stats only (no re-indexing)
chat_indexer.exe --stats-only

# Custom paths
chat_indexer.exe --projects-dir "C:\Users\you\.claude\projects" --db "C:\data\word_index.db"
```

The indexer skips already-indexed sessions, so it's safe to run repeatedly.
