╔══════════════════════════════════════════════════╗
║           chat_indexer — Quick Start             ║
╚══════════════════════════════════════════════════╝

WHAT IT DOES
  Scans your Claude Code session files and builds a
  SQLite database (word_index.db) tracking every word,
  character, symbol combo, and bracket pair — separately
  for you (user) and Claude (assistant).

──────────────────────────────────────────────────
USAGE
──────────────────────────────────────────────────

  1. Drop chat_indexer.exe anywhere you like.

  2. Double-click it, or run from a terminal:

       chat_indexer.exe

     It will automatically find your Claude Code sessions at:
       C:\Users\<you>\.claude\projects\

  3. To also print stats after indexing:

       chat_indexer.exe --stats

  4. To just see stats without re-indexing:

       chat_indexer.exe --stats-only

  5. Custom paths:

       chat_indexer.exe --projects-dir "D:\my_claude_projects" --db "D:\my_index.db"

──────────────────────────────────────────────────
OUTPUT
──────────────────────────────────────────────────

  word_index.db    — SQLite database (created in same
                     folder as the exe, or wherever
                     --db points)

  Open word_index.db with any SQLite viewer, e.g.:
    • DB Browser for SQLite (free): https://sqlitebrowser.org
    • VS Code SQLite extension

──────────────────────────────────────────────────
CLAUDE CODE INTEGRATION
──────────────────────────────────────────────────

  Put CLAUDE.md in your project folder alongside
  word_index.db. Claude Code will read it and know
  the full schema, useful queries, and how to
  analyze your word patterns and typos.

  Example: ask Claude Code —
    "Look at word_index.db and find words I commonly
     misspell based on low frequency variants of
     high frequency words."

──────────────────────────────────────────────────
NOTES
──────────────────────────────────────────────────

  • Already-indexed sessions are skipped automatically,
    so it's safe to run repeatedly as you add new chats.

  • Words are stored lowercased only — no other changes.
    Typos are preserved as their own entries.

  • Symbols are tracked both individually and as
    auto-detected combos (e.g. => != === () => {).

  • Bracket pairs () [] {} <> are tracked as matched
    pairs using a stack, so you see how often you
    open and close each type.
