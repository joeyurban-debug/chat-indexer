#!/usr/bin/env python3
"""
chat_indexer.py
Indexes every word, character, symbol combo, and bracket pair
from Claude Code session files (~/.claude/projects/**/*.jsonl)
into a SQLite database.
"""

import sqlite3
import json
import re
import os
import sys
import argparse
from pathlib import Path
from collections import defaultdict


# ── DB setup ──────────────────────────────────────────────────────────────────

def init_db(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS words (
            word        TEXT NOT NULL,
            speaker     TEXT NOT NULL CHECK(speaker IN ('user','assistant')),
            count       INTEGER DEFAULT 0,
            sessions    INTEGER DEFAULT 0,
            PRIMARY KEY (word, speaker)
        );

        CREATE TABLE IF NOT EXISTS characters (
            char        TEXT NOT NULL,
            speaker     TEXT NOT NULL CHECK(speaker IN ('user','assistant')),
            count       INTEGER DEFAULT 0,
            sessions    INTEGER DEFAULT 0,
            PRIMARY KEY (char, speaker)
        );

        CREATE TABLE IF NOT EXISTS symbol_combos (
            combo       TEXT NOT NULL,
            speaker     TEXT NOT NULL CHECK(speaker IN ('user','assistant')),
            count       INTEGER DEFAULT 0,
            sessions    INTEGER DEFAULT 0,
            PRIMARY KEY (combo, speaker)
        );

        CREATE TABLE IF NOT EXISTS bracket_pairs (
            pair        TEXT NOT NULL,
            speaker     TEXT NOT NULL CHECK(speaker IN ('user','assistant')),
            count       INTEGER DEFAULT 0,
            sessions    INTEGER DEFAULT 0,
            PRIMARY KEY (pair, speaker)
        );

        CREATE TABLE IF NOT EXISTS sessions (
            session_id  TEXT PRIMARY KEY,
            file_path   TEXT,
            indexed_at  TEXT DEFAULT (datetime('now'))
        );
    """)
    conn.commit()
    return conn


# ── Tokenisers ─────────────────────────────────────────────────────────────────

SYMBOL_CHARS = set(r'!@#$%^&*()-+=[]{}|;:\'",.<>?/\\`~')
BRACKET_OPEN  = {'(': '()', '[': '[]', '{': '{}', '<': '<>'}
BRACKET_CLOSE = {')', ']', '}', '>'}

def tokenize_words(text: str) -> list[str]:
    """Extract lowercased words (letters + digits runs)."""
    return re.findall(r"[a-zA-Z0-9_']+", text.lower())

def tokenize_chars(text: str) -> list[str]:
    """Every individual character (including symbols, spaces excluded)."""
    return [ch for ch in text if ch != ' ']

def tokenize_symbol_combos(text: str) -> list[str]:
    """
    Auto-detect runs of symbol characters as combos.
    e.g. '() => {' yields ['()', '=>', '{']
    Also yields individual symbols that are alone.
    """
    combos = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in SYMBOL_CHARS:
            # collect contiguous symbol run
            j = i + 1
            while j < len(text) and text[j] in SYMBOL_CHARS:
                j += 1
            run = text[i:j]
            if len(run) > 1:
                combos.append(run)
            # always also record individual chars inside the run
            for c in run:
                combos.append(c)
            i = j
        else:
            i += 1
    return combos

def tokenize_bracket_pairs(text: str) -> list[str]:
    """
    Track matched bracket pairs using a stack.
    Returns list of pair strings like '()', '[]', '{}', '<>'.
    """
    stack = []
    pairs = []
    for ch in text:
        if ch in BRACKET_OPEN:
            stack.append(BRACKET_OPEN[ch])
        elif ch in BRACKET_CLOSE:
            # find matching open on stack
            for idx in range(len(stack) - 1, -1, -1):
                if stack[idx][1] == ch:
                    pairs.append(stack.pop(idx))
                    break
    return pairs


# ── Accumulate into dicts before bulk-upserting ───────────────────────────────

def merge(target: dict, source: dict):
    for k, v in source.items():
        target[k] = target.get(k, 0) + v

def count_items(items: list[str]) -> dict[str, int]:
    d = defaultdict(int)
    for item in items:
        d[item] += 1
    return dict(d)


# ── Upsert helpers ─────────────────────────────────────────────────────────────

def bulk_upsert(conn: sqlite3.Connection, table: str, col: str,
                counts: dict[str, int], speaker: str):
    if not counts:
        return
    c = conn.cursor()
    for token, cnt in counts.items():
        c.execute(f"""
            INSERT INTO {table} ({col}, speaker, count, sessions)
            VALUES (?, ?, ?, 1)
            ON CONFLICT({col}, speaker) DO UPDATE SET
                count    = count + excluded.count,
                sessions = sessions + 1
        """, (token, speaker, cnt))


# ── JSONL parsing ──────────────────────────────────────────────────────────────

def extract_messages(jsonl_path: Path) -> list[tuple[str, str]]:
    """
    Returns list of (speaker, text) tuples from a Claude Code .jsonl file.
    Handles both plain message lines and nested content blocks.
    """
    messages = []
    try:
        with open(jsonl_path, encoding='utf-8', errors='replace') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue

                role = obj.get('role') or obj.get('type', '')
                if role not in ('user', 'assistant'):
                    # try nested message key
                    msg = obj.get('message', {})
                    role = msg.get('role', '')
                    content = msg.get('content', '')
                else:
                    content = obj.get('content', '')

                if role not in ('user', 'assistant'):
                    continue

                # content can be a string or list of blocks
                if isinstance(content, str):
                    text = content
                elif isinstance(content, list):
                    parts = []
                    for block in content:
                        if isinstance(block, dict):
                            parts.append(block.get('text', ''))
                        elif isinstance(block, str):
                            parts.append(block)
                    text = ' '.join(parts)
                else:
                    continue

                if text.strip():
                    messages.append((role, text))
    except Exception as e:
        print(f"  [warn] Could not read {jsonl_path}: {e}", file=sys.stderr)
    return messages


# ── Main indexer ───────────────────────────────────────────────────────────────

def index_file(conn: sqlite3.Connection, jsonl_path: Path):
    session_id = jsonl_path.stem
    c = conn.cursor()
    already = c.execute("SELECT 1 FROM sessions WHERE session_id=?",
                        (session_id,)).fetchone()
    if already:
        print(f"  skip (already indexed): {jsonl_path.name}")
        return

    messages = extract_messages(jsonl_path)
    if not messages:
        print(f"  skip (no messages): {jsonl_path.name}")
        return

    print(f"  indexing: {jsonl_path.name}  ({len(messages)} messages)")

    # accumulators per speaker
    acc: dict[str, dict[str, dict]] = {
        'user':      {'words': {}, 'chars': {}, 'combos': {}, 'pairs': {}},
        'assistant': {'words': {}, 'chars': {}, 'combos': {}, 'pairs': {}},
    }

    for speaker, text in messages:
        merge(acc[speaker]['words'],  count_items(tokenize_words(text)))
        merge(acc[speaker]['chars'],  count_items(tokenize_chars(text)))
        merge(acc[speaker]['combos'], count_items(tokenize_symbol_combos(text)))
        merge(acc[speaker]['pairs'],  count_items(tokenize_bracket_pairs(text)))

    for speaker in ('user', 'assistant'):
        bulk_upsert(conn, 'words',         'word',  acc[speaker]['words'],  speaker)
        bulk_upsert(conn, 'characters',    'char',  acc[speaker]['chars'],  speaker)
        bulk_upsert(conn, 'symbol_combos', 'combo', acc[speaker]['combos'], speaker)
        bulk_upsert(conn, 'bracket_pairs', 'pair',  acc[speaker]['pairs'],  speaker)

    c.execute("INSERT INTO sessions (session_id, file_path) VALUES (?,?)",
              (session_id, str(jsonl_path)))
    conn.commit()


def find_jsonl_files(root: Path) -> list[Path]:
    return sorted(root.rglob("*.jsonl"))


def print_stats(conn: sqlite3.Connection):
    c = conn.cursor()
    print("\n══════════════════════════════════════")
    print("  WORD INDEX STATS")
    print("══════════════════════════════════════")

    for speaker in ('user', 'assistant'):
        print(f"\n── {speaker.upper()} ──────────────────────────")
        rows = c.execute("""
            SELECT word, count FROM words
            WHERE speaker=?
            ORDER BY count DESC LIMIT 20
        """, (speaker,)).fetchall()
        print(f"  Top 20 words:")
        for word, cnt in rows:
            print(f"    {word:<25} {cnt:>6}")

        rows = c.execute("""
            SELECT combo, count FROM symbol_combos
            WHERE speaker=?
            ORDER BY count DESC LIMIT 15
        """, (speaker,)).fetchall()
        print(f"\n  Top 15 symbol combos:")
        for combo, cnt in rows:
            print(f"    {combo:<25} {cnt:>6}")

        rows = c.execute("""
            SELECT pair, count FROM bracket_pairs
            WHERE speaker=?
            ORDER BY count DESC LIMIT 10
        """, (speaker,)).fetchall()
        print(f"\n  Top 10 bracket pairs:")
        for pair, cnt in rows:
            print(f"    {pair:<25} {cnt:>6}")

    total_sessions = c.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
    total_words    = c.execute("SELECT SUM(count) FROM words WHERE speaker='user'").fetchone()[0] or 0
    print(f"\n  Sessions indexed : {total_sessions}")
    print(f"  Total user words : {total_words}")
    print("══════════════════════════════════════\n")


# ── CLI ────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Index Claude Code chat sessions into SQLite.")
    parser.add_argument(
        "--projects-dir", "-p",
        default=str(Path.home() / ".claude" / "projects"),
        help="Path to ~/.claude/projects (default: %(default)s)")
    parser.add_argument(
        "--db", "-d",
        default="word_index.db",
        help="Output SQLite database path (default: %(default)s)")
    parser.add_argument(
        "--stats", "-s",
        action="store_true",
        help="Print frequency stats after indexing")
    parser.add_argument(
        "--stats-only",
        action="store_true",
        help="Only print stats, skip indexing")
    args = parser.parse_args()

    db_path = args.db
    conn = init_db(db_path)

    if not args.stats_only:
        projects_dir = Path(args.projects_dir)
        if not projects_dir.exists():
            print(f"[error] Projects dir not found: {projects_dir}", file=sys.stderr)
            print("  Pass --projects-dir to specify a different path.", file=sys.stderr)
            sys.exit(1)

        files = find_jsonl_files(projects_dir)
        print(f"Found {len(files)} session file(s) in {projects_dir}\n")
        for f in files:
            index_file(conn, f)
        print(f"\nDone. Database saved to: {db_path}")

    if args.stats or args.stats_only:
        print_stats(conn)

    conn.close()


if __name__ == "__main__":
    main()
